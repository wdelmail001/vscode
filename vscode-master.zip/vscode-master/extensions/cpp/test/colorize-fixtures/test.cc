#if B4G_DEBUG_CHECK
 fprintf(stderr,"num_candidate_ret=%d:", num_candidate);
 for(int i=0;i<num_candidate;++i)
 fprintf(stderr,"%d,",user_candidate[i]);
 fprintf(stderr,";");
#endif

 void main(O obj) {
    LOG_INFO("not hilighted as string");
    LOG_INFO(obj << ", even worse; " << obj.x << " check this out.");
    // everything from this point on is interpeted as a string literal...
    O x;
    std::unique_ptr<O> o(new O);
    // sadness.

    sprintf(options, "STYLE=Keramik;TITLE=%s;THEME=%s", ...);
}


int main2() {
    printf(";");
    // the rest of
    asm("movw $0x38, %ax; ltr %ax");
    fn("{};");

    // the rest of
}